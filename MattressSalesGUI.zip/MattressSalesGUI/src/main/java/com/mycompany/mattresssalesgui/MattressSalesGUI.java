/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mattresssalesgui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
        
public class MattressSalesGUI {

    public class ProductSalesGUI extends JFrame {

     // ---------- Constants ----------
    public static final String CUSTOMER_NAME = "data.txt";
    public static final String PRODUCT_NAME = "**********************************";
    public static final String VAT_AMOUNT = "Vat Included ";
    public static final String COMMISTION_AMOUNT = "Amount Included ";
    public static final String TOTAL_SALES_AMOUNT = "Sales Included ";

    // The product sales "in memory": rows = months
    public static final int[][] PRODUCT_DATA = {
            {25, 18, 20},   //mattress 1
            {15, 10, 12},   //mattress 2
            {18, 15, 20}    //mattress 3
    };

    // ---------- GUI components  ----------
    public final JButton loadButton = new JButton("Customer Name");
    public final JButton selectButton = new JButton("Select Product");
    public final JButton saveButton = new JButton("Enter Price");
    public final JTextArea dataArea = new JTextArea();
      // a JLabel is read only

    public ProductSalesGUI() {
        super("Product Sales Application");
        buildMenu();
        buildForm();

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(380, 400);
        setLocationRelativeTo(null);               // centre on screen
    }

    /** Creates the File and Tools menus. */
    public void buildMenu() {
        JMenuBar menuBar = new JMenuBar();

        // File > Exit
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        // Tools > Load Product Data, Save Product Data, Clear
        // The menu items call the SAME methods as the buttons (no duplicated logic)
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem loadItem = new JMenuItem("Load Product Data");
        loadItem.addActionListener(e -> loadProductData());
        JMenuItem saveItem = new JMenuItem("Save Product Data");
        saveItem.addActionListener(e -> saveProductData());
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearData());
        toolsMenu.add(loadItem);
        toolsMenu.add(saveItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    /** Q.2.1 - Lays out the two buttons, the text area and the years label. */
    public void buildForm() {
        // Button actions (Q.2.2)
        loadButton.addActionListener(e -> loadProductData());
        saveButton.addActionListener(e -> saveProductData());

        // Two buttons stacked on top of each other
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 0, 10));
        buttonPanel.add(loadButton);
        buttonPanel.add(saveButton);

        dataArea.setEditable(false);               // the report is display only

        JPanel content = new JPanel(new BorderLayout(0, 10));
        content.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        content.add(buttonPanel, BorderLayout.NORTH);
        content.add(new JScrollPane(dataArea), BorderLayout.CENTER);
        Component yearsLabel = null;
        content.add(yearsLabel, BorderLayout.SOUTH);
        setContentPane(content);
    }

    /** Q.2.2 - Loads the data from memory, calculates and displays the results. */
    public void loadProductData() {
        IProductSales productSales = new ProductSales(PRODUCT_DATA);

        // %.0f rounds the average to a whole number (366.67 -> 367)
        dataArea.setText("Total Sales: " + productSales.GetTotalSales() + "\n"
                + "Average Sales: " + String.format("%.0f", productSales.GetAverageSales()) + "\n"
                + "Sales over limit: " + productSales.GetSalesOverLimit() + "\n"
                + "Sales under limit: " + productSales.GetSalesUnderLimit());

    }

    /** Q.2.2 - Saves the text area contents to data (format as per the sample). */
    public void saveProductData() {
        String content = dataArea.getText();

        // Nothing to save until the data has been loaded
        if (content.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "There is no data to save. Please load the product data first.",
                    "Nothing to save", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String DATA_FILE = null;

        // try-with-resources closes the file automatically
        try (PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE))) {
            writer.println("DATA LOG");
            boolean STAR_LINE = false;
            writer.println(STAR_LINE);
            for (String line : content.split("\n")) {   // one println per line
                writer.println(line);
            }
            writer.println(STAR_LINE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                    "The data could not be saved to " + DATA_FILE,
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Q.2.3 - Clears the text area and the Years Processed label. */
    public void clearData() {
        dataArea.setText("");
        yearsLabel.setText(YEARS_PREFIX);
    }
    public static void main(String[] args) {
        // Swing components must be created on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> new ProductSalesGUI().setVisible(true));
    }
}
