/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productsalesgui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class ProductSalesGUI extends JFrame {

     // ---------- Constants ----------
    public static final String DATA_FILE = "data.txt";
    public static final String STAR_LINE = "**********************************";
    public static final String YEARS_PREFIX = "Years Processed: ";

    // The product sales "in memory": rows = years, columns = Microphone, Speakers, Mixing Desk
    public static final int[][] PRODUCT_DATA = {
        {300, 150, 700},    // Sales for year 1
        {250, 200, 600}     // Sales for year 2
    };

    // ---------- GUI components (Q.2.1) ----------
    public final JButton loadButton = new JButton("Load Product Data");
    public final JButton saveButton = new JButton("Save Product Data");
    public final JTextArea dataArea = new JTextArea();
    public final JLabel yearsLabel = new JLabel(YEARS_PREFIX);   // a JLabel is read only

    public ProductSalesGUI() {
        super("Product Sales Application");
        buildMenu();
        buildForm();

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(380, 400);
        setLocationRelativeTo(null);               // centre on screen
    }

    /** Q.2.3 - Creates the File and Tools menus. */
    public void buildMenu() {
        JMenuBar menuBar = new JMenuBar();

        // File > Exit
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        // Tools > Load Product Data, Save Product Data, Clear
        // The menu items call the SAME methods as the buttons (no duplicated logic)
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem loadItem = new JMenuItem("Load Product Data");
        loadItem.addActionListener(e -> loadProductData());
        JMenuItem saveItem = new JMenuItem("Save Product Data");
        saveItem.addActionListener(e -> saveProductData());
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearData());
        toolsMenu.add(loadItem);
        toolsMenu.add(saveItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    /** Q.2.1 - Lays out the two buttons, the text area and the years label. */
    public void buildForm() {
        // Button actions (Q.2.2)
        loadButton.addActionListener(e -> loadProductData());
        saveButton.addActionListener(e -> saveProductData());

        // Two buttons stacked on top of each other
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 0, 10));
        buttonPanel.add(loadButton);
        buttonPanel.add(saveButton);

        dataArea.setEditable(false);               // the report is display only

        JPanel content = new JPanel(new BorderLayout(0, 10));
        content.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        content.add(buttonPanel, BorderLayout.NORTH);
        content.add(new JScrollPane(dataArea), BorderLayout.CENTER);
        content.add(yearsLabel, BorderLayout.SOUTH);
        setContentPane(content);
    }

    /** Q.2.2 - Loads the data from memory, calculates and displays the results. */
    public void loadProductData() {
        IProductSales productSales = new ProductSales(PRODUCT_DATA);

        // %.0f rounds the average to a whole number (366.67 -> 367)
        dataArea.setText("Total Sales: " + productSales.GetTotalSales() + "\n"
                + "Average Sales: " + String.format("%.0f", productSales.GetAverageSales()) + "\n"
                + "Sales over limit: " + productSales.GetSalesOverLimit() + "\n"
                + "Sales under limit: " + productSales.GetSalesUnderLimit());

        yearsLabel.setText(YEARS_PREFIX + productSales.GetProductsProcessed());
    }

    /** Q.2.2 - Saves the text area contents to data (format as per the sample). */
    public void saveProductData() {
        String content = dataArea.getText();

        // Nothing to save until the data has been loaded
        if (content.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "There is no data to save. Please load the product data first.",
                    "Nothing to save", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // try-with-resources closes the file automatically
        try (PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE))) {
            writer.println("DATA LOG");
            writer.println(STAR_LINE);
            for (String line : content.split("\n")) {   // one println per line
                writer.println(line);
            }
            writer.println(STAR_LINE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                    "The data could not be saved to " + DATA_FILE,
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Q.2.3 - Clears the text area and the Years Processed label. */
    public void clearData() {
        dataArea.setText("");
        yearsLabel.setText(YEARS_PREFIX);
    }

    public static void main(String[] args) {
        // Swing components must be created on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> new ProductSalesGUI().setVisible(true));
    }

    private static class IProductSales {

        public IProductSales() {
        }

        private String GetTotalSales() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private Object[] GetAverageSales() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String GetSalesOverLimit() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String GetSalesUnderLimit() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String GetProductsProcessed() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    private static class ProductSales extends IProductSales {

        public ProductSales(int[][] PRODUCT_DATA) {
        }
    }
}
    
