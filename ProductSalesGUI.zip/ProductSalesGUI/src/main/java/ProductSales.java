/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class ProductSales implements IProductSales {
    /**
 * QUESTION 2 - Q.2.4
 * Holds the product sales data and calculates the totals.
 * The 2D array holds the sales: rows = years, columns = products
 * (Microphone, Speakers, Mixing Desk).
 */

    // The retailer's sales limit, used to decide if a product sale was a success
    public static final int SALES_LIMIT = 500;

    private final int[][] productSales;

    public ProductSales(int[][] productSales) {
        this.productSales = productSales;
    }

    public int[][] GetProductSales() {
        return productSales;
    }

    /** Adds up every sale in the table. */
    public int GetTotalSales() {
        int total = 0;
        for (int[] year : productSales) {
            for (int sale : year) {
                total += sale;
            }
        }
        return total;
    }

    /** Average = total / number of sales figures. */
    public double GetAverageSales() {
        int count = 0;
        for (int[] year : productSales) {
            count += year.length;
        }

        if (count == 0) {
            return 0;                              // avoid dividing by zero
        }
        return (double) GetTotalSales() / count;   // (double) keeps the decimals
    }

    /** Number of sales that are greater than the sales limit. */
    public int GetSalesOverLimit() {
        int over = 0;
        for (int[] year : productSales) {
            for (int sale : year) {
                if (sale > SALES_LIMIT) {
                    over++;
                }
            }
        }
        return over;
    }

    /** Number of sales that are less than the sales limit. */
    public int GetSalesUnderLimit() {
        int under = 0;
        for (int[] year : productSales) {
            for (int sale : year) {
                if (sale < SALES_LIMIT) {
                    under++;
                }
            }
        }
        return under;
    }

    /** Number of years processed = number of rows in the table. */
    public int GetProductsProcessed() {
        return productSales.length;
    }
}
