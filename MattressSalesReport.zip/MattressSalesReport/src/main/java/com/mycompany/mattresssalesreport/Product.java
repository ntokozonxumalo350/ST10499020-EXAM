/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mattresssalesreport;

import javax.swing.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.*;
import java.io.*;
import java.util.List;

public class Product {
    
    public interface IProduct {
        
    int TotalSales(int[][] productSales);
    double AverageSales(int[][] productSales);
    double GetAverageProductSold();
    String GetMostPopularProduct();
    }
    
    public class ProductSales implements IProduct {

    /** Adds up every sale in the 2D array. */
    @Override
    public int TotalSales(int[][] productSales) {
        int total = 0;
        for (int[] month : productSales) {          // each row (month)
            for (int sale : month) {                // each column (month)
                total += sale;
            }
        }
        return total;
    }

    /** Average = total / number of sales. */
    @Override
    public double AverageSales(int[][] productSales) {
        // Count how many sales figures there are in the whole table
        int count = 0;
        for (int[] month : productSales) {
            count += month.length;
        }

        if (count == 0) {
            return 0;                              
        }

        
        return (double) TotalSales(productSales) / count;
    }

    /** Lowest single sale in the table. */
    @Override
    public String GetMostPopularProduct; {
        int topIndex = 0; // assume first movie is best, then compare the rest
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[topIndex]) {
                topIndex = i;
            }
        }
    }
    }
