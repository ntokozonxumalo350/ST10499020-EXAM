/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mattresssalesreport;

import javax.swing.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.*;
import java.io.*;
import java.util.List;

public class MattressSalesReport {
    
    /**
 * QUESTION 1 - Q.1.1
 * Produces the mattress sales report.
 */
 public static void main(String[] args) {

        // Single-dimensional arrays
        String[] product = {"Cozy Night Monach Mattress", "Restonic Bardardos Mattress", "Sealy Phuket Mattress"};
        String[] months = {"JAN", "FEB", "MAR"};
        int[] totals = new int[product.length];

        // Two-dimensional array: rows = movies, columns = months
        int[][] sales = {
            {25, 18, 20},   //mattress 1
            {15, 10, 12},   //mattress 2
            {18, 15, 20}    //mattress 3
        };

        // Calculate total sales for each mattress
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                totals[i] += sales[i][j];
            }
        }

        // Find the top performing movie
        int topIndex = 0;
        for (int i = 1; i < totals.length; i++) {
            if (totals[i] > totals[topIndex]) {
                topIndex = i;
            }
        }

        // Display the report
        System.out.println("MATTRESS SALES REPORT - 2026");
        System.out.println();

        // Month headings
        System.out.printf("%-15s", "");
        for (String month : months) {
            System.out.printf("%-10s", month);
        }
        System.out.println();
        System.out.println("-------------------------------------------");

        // Sales per mattress per month
        for (int i = 0; i < product.length; i++) {
            System.out.printf("%-15s", product[i]);
            for (int j = 0; j < sales[i].length; j++) {
                System.out.printf("%-10d", sales[i][j]);
            }
            System.out.println();
        }

        System.out.println();

        // Totals per sales
        for (int i = 0; i < product.length; i++) {
            System.out.println("Total movie ticket sales for " + product[i] + " " + totals[i]);
        }

        System.out.println();
        System.out.println("Top performing movie: " + product[topIndex]);
    }
}