/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mattresssalesreport;

/**
 *
 * @author User
 */
public class PrintProduct {
    
    public class Product implements IProduct {

    /** Adds up ONE learner's marks (one row of the 2D array). */
    public int ProductSales(int[] productSales) {
        int total = 0;
        for (int _ : productSales) {
            total += sales;
        }
        return total;
    }

    /** Returns the learner whose total is highest (tracks the INDEX of the best total). */
    public String TopProduct(String[] product, int[] sales) {
        int topIndex = 0;
        for (int i = 1; i < totals.length; i++) {
            if (totals[i] > totals[topIndex]) {
                topIndex = i;
            }
        }
        return product[topIndex];
    }

    /** Average of EVERY mark in the table (12 values), not the average of the rows. */
    public double AverageProductSales(int[][] sales) {
        int sum = 0;
        int count = 0;
        for (int[] product : sales) {
            for (int sales : product) {
                sum += sales;
                count++;
            }
        }
        return count == 0 ? 0 : (double) sum / count; // cast BEFORE dividing
    }

    public int HighestSales(int[][] marks) {
        int highest = marks[0][0];
        for (int[] product : sales) {
            for (int sales : product) {
                if (sales > highest) highest = sales;
            }
        }
        return highest;
    }
}
