/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.productsalesreport;

/**
 *
 * @author User
 */
public interface IProducts {

/**
 * QUESTION 1 - Q.1.2
 * Interface exactly as given in the question paper.
 * (The paper's text calls it IProductSales, but the code block and the
 * marking rubric both use the name IProduct, so that name is used here.)
 */
public interface IProduct {

    int TotalSales(int[][] productSales);

    double AverageSales(int[][] productSales);

    int MaxSale(int[][] productSales);

    int MinSale(int[][] productSales);
}

/**
 * QUESTION 1 - Q.1.2
 * Class that implements IProduct. Each calculation has its own method.
 * The 2D array holds the sales: rows = years, columns = quarters.
 */
public class ProductSales implements IProduct {

    /** Adds up every sale in the 2D array. */
    @Override
    public int TotalSales(int[][] productSales) {
        int total = 0;
        for (int[] year : productSales) {          // each row (year)
            for (int sale : year) {                // each column (quarter)
                total += sale;
            }
        }
        return total;
    }

    /** Average = total / number of sales. */
    @Override
    public double AverageSales(int[][] productSales) {
        // Count how many sales figures there are in the whole table
        int count = 0;
        for (int[] year : productSales) {
            count += year.length;
        }

        if (count == 0) {
            return 0;                              // avoid dividing by zero
        }

        // (double) makes this a decimal division: 2200 / 6 = 366.67, not 366
        return (double) TotalSales(productSales) / count;
    }

    /** Highest single sale in the table. */
    @Override
    public int MaxSale(int[][] productSales) {
        int max = Integer.MIN_VALUE;               // any real sale will be bigger than this
        for (int[] year : productSales) {
            for (int sale : year) {
                if (sale > max) {
                    max = sale;
                }
            }
        }
        return max;
    }

    /** Lowest single sale in the table. */
    @Override
    public int MinSale(int[][] productSales) {
        int min = Integer.MAX_VALUE;               // any real sale will be smaller than this
        for (int[] year : productSales) {
            for (int sale : year) {
                if (sale < min) {
                    min = sale;
                }
            }
        }
        return min;
    }
}
}
