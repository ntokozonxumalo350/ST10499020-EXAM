/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productsalesreport;

import java.util.ArrayList;
import java.util.Scanner;

public class ProductSalesReport {

    /**
 * QUESTION 1 - Q.1.1
 * Produces the product sales report for two years (quarters 1 to 3).
 */

    // Width of the divider lines in the report
    public static final String LINE = "-".repeat(48);

    public static void main(String[] args) {

        // 1D array: column headings
        String[] quarters = {"QUARTER 1", "QUARTER 2", "QUARTER 3"};

        // 2D array: rows = years, columns = quarters
        int[][] sales = {
            {300, 150, 700},    // Year 1
            {250, 200, 600}     // Year 2
        };

        // Object that does the calculations (Q.1.2)
        IProduct product = new ProductSales();

        // ---------- Title ----------
        System.out.println("PRODUCT SALES REPORT - 2025");
        System.out.println(LINE);

        // ---------- Rows and columns of the data ----------
        System.out.printf("%-12s", "");                       // empty corner cell
        for (String quarter : quarters) {
            System.out.printf("%-12s", quarter);
        }
        System.out.println();

        for (int i = 0; i < sales.length; i++) {
            System.out.printf("%-12s", "YEAR " + (i + 1));    // row heading
            for (int j = 0; j < sales[i].length; j++) {
                System.out.printf("%-12d", sales[i][j]);
            }
            System.out.println();
        }
        System.out.println(LINE);

        // ---------- Summary: total, average, maximum and minimum ----------
        System.out.printf("%-15s%d%n", "Total sales:", product.TotalSales(sales));
        System.out.printf("%-15s%.0f%n", "Average sales:", product.AverageSales(sales));
        System.out.printf("%-15s%d%n", "Maximum sale:", product.MaxSale(sales));
        System.out.printf("%-15s%d%n", "Minimum sale:", product.MinSale(sales));
        System.out.println(LINE);
    }
}